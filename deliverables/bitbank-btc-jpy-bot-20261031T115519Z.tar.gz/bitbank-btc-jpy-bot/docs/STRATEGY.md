# BTC/JPY moving-average strategy

Authority: [README.md](../README.md) percents and “buy possible amount / sell all”.

## Market

- Exchange: Bitbank only
- Pair: `btc_jpy`
- Min order size: 0.0001 BTC
- Price tick: 1 JPY
- Buy size: possible amount (`free_amount` JPY × usage × fee buffer / price, quantized)
- Sell size: all free BTC (quantized)
- Primary candle: `1hour` SMA(20); golden cross SMA(20)/SMA(50)
- Timezone: Japan (JST)

## README rules

Priority while a position is open: **STOP > pattern SELL > TAKE_PROFIT > BUY**.
Pattern sells (SELL1–4) still wait for a new closed candle and do not sell on the entry candle.
Stop-loss and take-profit use the latest public price on every loop, including the same hour, and are sent as market orders.
A take-profit is skipped when the exit would not be profitable after fees.
HOLD always has a reason.

### Buys (possible amount)

| ID | When | Take profit |
| --- | --- | --- |
| R1 / BUY1 | MA was in a downtrend, then flattened or turned up, **and** BTC crosses **above** the MA | +3% |
| R2 / BUY2 | MA is in an **uptrend or FLAT** and BTC crosses **below** the MA | +8% if golden cross, else +5% |
| R3 / BUY3 | Price was **≥ BUY3_EXTEND above** the MA (default **1%**), declined **without touching** the MA, then rose again | +4% |
| R4 / BUY4 | Price was **≥ BUY4_DIP below** a **DOWN or FLAT** MA (default **1%**), then rose again | +5% |

BUY3 / BUY4 dip-extend defaults are **1%** (`BUY3_EXTEND` / `BUY4_DIP`; was 5%). BUY size uses realtime `free_amount * MAX_BALANCE_USAGE` (default 0.95). Fee-edge and HTF filters still block uneconomic or HTF-down buys.

### Sells (flatten)

| ID | When |
| --- | --- |
| R5 / SELL1 | Price was **≥4% above** the MA, then declined |
| R6 / SELL2 | Price declines **and** crosses below the MA, then keeps falling |
| R7 / SELL3 | Price crosses **up** through a MA that is still in a **downtrend** |
| R8 / SELL4 | Price was **≥4% below** the MA, rose **without reaching** the MA, then fell again |

Trend uses `slope = (ma - prev_ma) / prev_ma` versus `MA_SLOPE_THRESHOLD=0.0005`.

## Higher-timeframe filter (not a second strategy)

When `ENABLE_HTF_FILTER=true` (default), a **new BUY** is blocked if the 4-hour
and 1-day SMA slopes are both DOWN, or if those candles cannot be read. Sells
and take-profit are unchanged. `--synthetic` smoke tests skip this filter.
