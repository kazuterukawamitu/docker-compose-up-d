#!/usr/bin/env python3
"""Repo-root quality pipeline: compileall, pytest, ruff (safe select only)."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from bitbank_bot.quality import main

if __name__ == "__main__":
    raise SystemExit(main())
